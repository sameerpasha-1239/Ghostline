Rubric-Local — 100% Offline AI Question Recognition & Solver Engine
===================================================================

QUICK START:
1. Ensure Ollama is installed and running on your PC (https://ollama.com).
2. Recommended: Run `ollama pull phi3:mini` in your terminal.
3. Double-click `Run-Rubric-Local.bat` to start Rubric-Local.
4. Place your mouse cursor over any question on your screen and press:

     Alt + /

   The answer and confidence badge will appear instantly in your tray and HUD!

PRIVACY & OFFLINE GUARANTEE:
Rubric-Local runs entirely locally on your Windows machine with 0 external network requests.
