@echo off
title Rubric-Local Portable
cd /d "%~dp0app"
start "" "Rubric-Local.exe"
exit
